
void func(int a, int b)
{
    int x, y;
    x = a + b;
}
