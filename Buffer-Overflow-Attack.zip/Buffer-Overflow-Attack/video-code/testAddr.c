#include <stdio.h>

void* getAddr(){
    return __builtin_return_address(0);
}

int main(){
    printf("Code located at: %p\n", getAddr());
    return 0;
}
