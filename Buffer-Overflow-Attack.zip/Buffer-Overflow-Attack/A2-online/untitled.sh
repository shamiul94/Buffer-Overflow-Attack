sudo sysctl -w kernel.randomize_va_space=0

gcc -g -z execstack -fno-stack-protector -o gdb_stack online.c

gdb --nx gdb_stack

b copy 

run 

'n' , enter , enter , ...., 

p $ebp

p &buffer

p/d 0xbfffeb48 - 0xbfffe758

./exploit.py

sudo chown root gdb_stack
sudo chmod 4755 gdb_stack

./exploit.py 
./gdb_stack